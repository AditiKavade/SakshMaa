package com.example.pblapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class admin_page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_page);
        Button btn = (Button) findViewById(R.id.recordbtn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent collrec = new Intent(admin_page.this, Collection.class);
                startActivity(collrec);
            }
        });
        Button btn1 = (Button) findViewById(R.id.loanbtn);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent loanI = new Intent(admin_page.this, loan.class);
                startActivity(loanI);
            }
        });
        Button btn2 = (Button) findViewById(R.id.remUser);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent RemI = new Intent(admin_page.this, Remove.class);
                startActivity(RemI);
            }
        });
        Button btn3 = (Button) findViewById(R.id.btnadduser);
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent AddU = new Intent(admin_page.this, AddUser.class);
                startActivity(AddU);
            }
        });
    }

    public void viewinfo(View view) {
        Intent i = new Intent(admin_page.this, viewinformation.class);

        startActivity(i);
    }
}