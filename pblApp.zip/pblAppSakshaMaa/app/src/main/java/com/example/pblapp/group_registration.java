package com.example.pblapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import java.util.Random;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class group_registration extends AppCompatActivity {
    Button btnCreate;
    TextInputEditText etGroupName;
    TextInputEditText etAdminName;
    TextInputEditText etMobileNo;
    TextInputEditText etStartYear;
    TextInputEditText etStartMonth;
    TextInputEditText etMonthlySaving;

    TextInputEditText etAdminPass;
    private DatabaseReference database;

    //Random code generation
    public String generateRandomCode(int length)
    {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        Random random = new Random();
        StringBuilder code = new StringBuilder(length);

        for(int i = 0; i < length; i++)
        {
            int index = random.nextInt(characters.length());
            code.append(characters.charAt(index));
        }
        return code.toString();
    }
    private String generateUniqueCode()
    {
        String groupCode = generateRandomCode(6);
        //To check if the generated code already exists in the database
        database.child(groupCode).get().addOnSuccessListener(new OnSuccessListener<DataSnapshot>() {
            @Override
            public void onSuccess(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                {
                    generateUniqueCode();
                }
            }
        });
        return groupCode;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_registration);
        btnCreate = findViewById(R.id.create_btn);
        etGroupName = findViewById(R.id.group_name);
        etAdminName = findViewById(R.id.admin_name);
        etMobileNo = findViewById(R.id.mobile_no);
        etStartYear = findViewById(R.id.start_year);
        etStartMonth = findViewById(R.id.start_month);
        etMonthlySaving = findViewById(R.id.monthly_saving);
        etAdminPass = findViewById(R.id.admin_pass);
        database = FirebaseDatabase.getInstance().getReference("Groups");


        btnCreate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                String groupName = etGroupName.getText().toString();
                String adminName = etAdminName.getText().toString();
                String mobileNo = etMobileNo.getText().toString();
                String startYear = etStartYear.getText().toString();
                String startMonth = etStartMonth.getText().toString();
                String monthlySaving = etMonthlySaving.getText().toString();
                String adminPassword = etAdminPass.getText().toString();
                String groupCode = generateUniqueCode();


                Group group = new Group(groupName, adminName, mobileNo, startYear, startMonth, monthlySaving, groupCode, adminPassword);

                database.child(groupCode).setValue(group).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Toast.makeText(group_registration.this, "Group created successfully", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(group_registration.this, "Failed", Toast.LENGTH_SHORT).show();
                            }
                        });
            }// On click

        });
    }//onCreate
}