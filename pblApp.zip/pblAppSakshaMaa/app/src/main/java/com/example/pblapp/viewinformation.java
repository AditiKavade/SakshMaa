package com.example.pblapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class viewinformation extends AppCompatActivity {
    Button editProfile,groupinfo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewinformation);
        editProfile = findViewById(R.id.btnprofilesetting);
        editProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editprofileIntent ;
                editprofileIntent = new Intent(viewinformation.this,profilesettings.class);
                startActivity(editprofileIntent);
            }
        });

        groupinfo = findViewById(R.id.btnbachatgatinfo);
        groupinfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent grpsetting = new Intent(viewinformation.this,GroupInformation.class);
                startActivity(grpsetting);
            }
        });
    }


    public void editinfo(View view) {
        Intent i = new Intent(viewinformation.this, admin_page.class);

        startActivity(i);
    }
}