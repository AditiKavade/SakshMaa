package com.example.pblapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class profilesettings extends AppCompat {
    ImageButton arrow;
    Button eng,mar;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profilesettings);

        eng = findViewById(R.id.engbtnprofset);
        mar = findViewById(R.id.marbtnprofset);
        LanguageManager lang = new LanguageManager(this);
        eng.setOnClickListener(view -> {
            lang.updateResource("en");
            recreate();
        });

        mar.setOnClickListener(view -> {
            lang.updateResource("mr");
            recreate();
        });

        arrow = findViewById(R.id.profilearrow);
        arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent backarrow = new Intent(profilesettings.this,viewinformation.class);
                startActivity(backarrow);
            }
        });
    }
}