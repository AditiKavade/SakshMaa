package com.example.pblapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AdminLogin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);


        Button viewinfo = findViewById(R.id.viewbtn);
        viewinfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent viewinf = new Intent(AdminLogin.this,viewinformation.class);
                startActivity(viewinf);
            }
        });

        Button btn = (Button) findViewById(R.id.recordbtn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent collrec = new Intent(AdminLogin.this, Collection.class);
                startActivity(collrec);
            }
        });


        Button btn1 = (Button) findViewById(R.id.loanbtn);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent loanI = new Intent(AdminLogin.this, loan.class);
                startActivity(loanI);
            }
        });


        Button btn2 = (Button) findViewById(R.id.remUser);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent RemI = new Intent(AdminLogin.this, Remove.class);
                startActivity(RemI);
            }
        });


        Button btn3 = (Button) findViewById(R.id.btnadduser);
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent AddU = new Intent(AdminLogin.this, AddUser.class);
                startActivity(AddU);
            }
        });


    }
}