package com.example.pblapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Userlogin extends AppCompatActivity {
    Button btnallinfo, profsetting, grpinfo;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userlogin);

        btnallinfo = findViewById(R.id.allrecuser);
        btnallinfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent allinfointent = new Intent(Userlogin.this,AllRecords.class);
                startActivity(allinfointent);
            }
        });

        profsetting = findViewById(R.id.btnprofilesettinguser);
        profsetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent profsettingintent = new Intent(Userlogin.this,profilesettings.class);
                startActivity(profsettingintent);
            }
        });

        grpinfo = findViewById(R.id.btnbachatgatinfouser);
        grpinfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent grpinfointent = new Intent(Userlogin.this, GroupInformation.class);
                startActivity(grpinfointent);
            }
        });

    }
}