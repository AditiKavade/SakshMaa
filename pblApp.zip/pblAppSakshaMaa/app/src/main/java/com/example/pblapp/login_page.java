package com.example.pblapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

interface AdminValidationCallback
{
    void onAdminValidationResult(boolean isValid);
}
public class login_page extends AppCompatActivity {
    TextInputEditText etGroupCode;
    TextInputEditText tvGroupName;
    TextInputEditText etUserName;
    TextInputEditText etPassword;
    Button btnSearch;
    Button btnLogin;

    RadioGroup RadioGroupRoles;
    RadioButton radioButtonAdmin;
    RadioButton radioButtonTreasurer;
    RadioButton radioButtonMember;

    private DatabaseReference database;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_page);
        etGroupCode = findViewById(R.id.group_code);
        tvGroupName = findViewById(R.id.group_name_login);
        btnSearch = findViewById(R.id.btn_search);
        etUserName = findViewById(R.id.uname);
        etPassword = findViewById(R.id.passw);
        btnLogin = findViewById(R.id.btnLogin);
        RadioGroupRoles = findViewById(R.id.radioGroupRoles);
        radioButtonAdmin = findViewById(R.id.radioButtonAdmin);
        radioButtonTreasurer = findViewById(R.id.radioButtonTreasurer);
        radioButtonMember = findViewById(R.id.radioButtonMember);

        //getting reference to root node in database (initializing database)
        database = FirebaseDatabase.getInstance().getReference("Groups");

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String group_code = etGroupCode.getText().toString();

                if(!group_code.isEmpty())
                {
                    readDataCode(group_code);
                }
                else
                {
                    Toast.makeText(login_page.this, "Group not found!", Toast.LENGTH_SHORT).show();
                }
            }//onClick
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String group_code = etGroupCode.getText().toString();
                String user_name = etUserName.getText().toString();
                String password = etPassword.getText().toString();

                if(validateInputs(group_code, user_name, password))
                {
                    //Action based on selected user role
                    if(radioButtonAdmin.isChecked())
                    {
                        //check if admin is valid or not
                        isAdminValid(group_code, user_name, password, new AdminValidationCallback()
                        {
                            @Override
                            public void onAdminValidationResult(boolean isValid) {
                                if (isValid)
                                {
                                    //valid admin
                                    Toast.makeText(login_page.this, "Admin login successful", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(login_page.this, admin_page.class);
                                    startActivity(intent);
                                }
                            }
                        });//isAdminValid
                    }//if
                    else if (radioButtonMember.isChecked()) {
                        Intent intent = new Intent(login_page.this, Userlogin.class);
                        startActivity(intent);

                    } //else if
                    else if (radioButtonTreasurer.isChecked()) {
                        Intent intent = new Intent(login_page.this, treasurer.class);
                        startActivity(intent);
                    }
                }//outer if

            }//onClick


            //Function to validate all inputs
            private boolean validateInputs(String group_code, String user_name, String password)
            {
                if(group_code.isEmpty())
                {
                    etGroupCode.setError("Please enter your group code");
                    return false;
                }
                if(user_name.isEmpty())
                {
                    etUserName.setError("Please enter your group code");
                    return false;
                }
                if(password.isEmpty())
                {
                    etPassword.setError("Please enter your group code");
                    return false;
                }
                return true;
            }//validateInputs

            private void isAdminValid(String group_code, String user_name, String password, AdminValidationCallback callback)
            {
                database.child(group_code).get().addOnSuccessListener(new OnSuccessListener<DataSnapshot>() {
                    @Override
                    public void onSuccess(DataSnapshot dataSnapshot) {
                        //If dataSnapshot exists
                        if(dataSnapshot.exists())
                        {
                            String databaseUserName = String.valueOf(dataSnapshot.child("admin_name").getValue());
                            String databasePassword = String.valueOf(dataSnapshot.child("admin_password").getValue());

                            if (databaseUserName.equals(user_name))
                            {
                                if (databasePassword.equals(password))
                                {
                                    //Username and password match
                                    callback.onAdminValidationResult(true);
                                }
                                else
                                {
                                    //password does not match
                                    Toast.makeText(login_page.this, "Password doesn't match!", Toast.LENGTH_SHORT).show();
                                    etPassword.setError("Please enter correct password");
                                    callback.onAdminValidationResult(false);
                                }
                            }
                            else
                            {
                                //Username does not match
                                Toast.makeText(login_page.this, "Your name doesn't match!", Toast.LENGTH_SHORT).show();
                                etUserName.setError("Please enter correct name");
                                callback.onAdminValidationResult(false);
                            }
                        }
                        //If dataSnapshot doesn't exist
                        else
                        {
                            Toast.makeText(login_page.this, "Group doesn't exist", Toast.LENGTH_SHORT).show();
                            callback.onAdminValidationResult(false);
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(login_page.this, "Failed, error in DB", Toast.LENGTH_SHORT).show();
                        callback.onAdminValidationResult(false);
                    }
                });
            }//isAdminValid
        });
    }//onCreate
    private void readDataCode(String group_code) {

        database.child(group_code).get().addOnSuccessListener(new OnSuccessListener<DataSnapshot>() {
            @Override
            public void onSuccess(DataSnapshot dataSnapshot) {
                String group_name = String.valueOf(dataSnapshot.child("group_name").getValue());

                Log.d("loginActivity","Group Code" + group_name);

                tvGroupName.setText(group_name);

            }//on success
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(login_page.this, "Group name not found", Toast.LENGTH_SHORT).show();
            }
        });
    }// readDataCode







}