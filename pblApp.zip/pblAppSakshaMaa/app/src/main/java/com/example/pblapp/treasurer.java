package com.example.pblapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class treasurer extends AppCompatActivity {
    Button btnallinfo, profsetting, grpinfo, loan;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_treasurer);

        btnallinfo = findViewById(R.id.allrecuser);
        btnallinfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent allinfointent = new Intent(treasurer.this,AllRecords.class);
                startActivity(allinfointent);
            }
        });

        profsetting = findViewById(R.id.btnprofilesettinguser);
        profsetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent profsettingintent = new Intent(treasurer.this,profilesettings.class);
                startActivity(profsettingintent);
            }
        });

        grpinfo = findViewById(R.id.btnbachatgatinfouser);
        grpinfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent grpinfointent = new Intent(treasurer.this, GroupInformation.class);
                startActivity(grpinfointent);
            }
        });

        loan = findViewById(R.id.btnloan);
        loan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent loan = new Intent(treasurer.this, loan.class);
                startActivity(loan);
            }
        });

    }
}